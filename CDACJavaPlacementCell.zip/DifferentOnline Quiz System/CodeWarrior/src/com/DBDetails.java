package com;

public class DBDetails {
	static String USER_TABLE="USER";
	static String ID_COL="ID";
	static String NAME_COL="NAME";
	static String EMAIL_COL="EMAIL";
	
	static String ADMIN_TABLE="ADMIN";
	static String PASSWORD_COL="PASSWORD";
	
	static String QUESTION_TABLE="QUESTION";
	static String TEXT_COL="TEXT";
	static String SET_COL="Q_SET";
	static String ANSWER_COL="ANSWER";
	
	static String CHOICE_TABLE="CHOICE";
	static String QUESTION_ID_COL="Q_ID";

	static String RESULT_TABLE="RESULT";
	static String USER_ID_COL="U_ID";
}