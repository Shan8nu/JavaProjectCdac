package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.model.DbConnection;

public class RemoveCompanyImpl {
	
	Connection con = null;
	public boolean RemoveCompany(int cid)
	{
		String query1 = "delete from companylist where cid=?";		
		try {
    		con = DbConnection.getConnection();
			PreparedStatement pst = con.prepareStatement(query1);
			pst.setInt(1, cid);
			int record = pst.executeUpdate();	
				
			if(record==1)
			{
				System.out.println("deleted");
				return true;
			}
		}  
    	catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}	    	
		return false;
	}
}
