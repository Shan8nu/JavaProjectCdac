package com.model;

public class CompanyPojo {

	private String companyName;
	private String description;
	private int vacencies;
	private String location;
	private int salary;
	private String criteria;
	private String stream;
	private String logo;
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getVacencies() {
		return vacencies;
	}
	public void setVacencies(int vacencies) {
		this.vacencies = vacencies;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getCriteria() {
		return criteria;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public CompanyPojo(String companyName, String description, int vacencies, String location, int salary,
			String criteria, String stream, String logo) {
		super();
		this.companyName = companyName;
		this.description = description;
		this.vacencies = vacencies;
		this.location = location;
		this.salary = salary;
		this.criteria = criteria;
		this.stream = stream;
		this.logo = logo;
	}

	
}

