package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.model.DbConnection;
import com.model.DaoLayer;
import com.model.PojoClass;
import com.model.StudentDetailsPojo;

public class SignupDaoImplement implements DaoLayer {

	Connection con = null;
	@Override
	public boolean insertsignup(PojoClass pc)
	{	
		String query = "insert into signup values(default,?,?,?)";
		try {
			con  = DbConnection.getConnection();
			PreparedStatement pst = con.prepareStatement(query);

			pst.setString(1, pc.getsusername());
			pst.setString(2, pc.getspassword());
			pst.setString(3, pc.getscpassword());
			
			int record = pst.executeUpdate();
			
			if(record==1)
				{
					System.out.println("Insert successfully");
					return true;				
				}		
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}	
	return false;
	}
	@Override
	public boolean login(PojoClass pc) {
		return false;
	}
	@Override
	public boolean studentDataInsert(StudentDetailsPojo sdp) {
		return false;
	}
}
