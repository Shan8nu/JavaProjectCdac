package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.CompanyPojo;
import com.model.DbConnection;
import com.model.PojoClass;

public class CompanyDaoImplement {
	
	Connection con = null;
	public ResultSet companyfetch(CompanyPojo cp)
	{	
		String query = "select * from companylist";
		try {
			con  = DbConnection.getConnection();
			PreparedStatement pst = con.prepareStatement(query);

			
			int record = pst.executeUpdate();
			
			if(record==1)
				{
					System.out.println("Insert successfully");				
				}		
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;	
	}
}
