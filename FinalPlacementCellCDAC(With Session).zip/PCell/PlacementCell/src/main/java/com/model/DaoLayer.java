package com.model;

public interface DaoLayer {

	public boolean insertsignup(PojoClass pc);

	public boolean login(PojoClass pc);
	
	public boolean studentDataInsert(StudentDetailsPojo sdp);
}
