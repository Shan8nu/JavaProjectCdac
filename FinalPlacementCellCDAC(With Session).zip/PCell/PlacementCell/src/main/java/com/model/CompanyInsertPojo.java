package com.model;

public class CompanyInsertPojo 
{
	private String companyName;
	private String companyDescription;
	private String designation;
	private String email;
	private int vacancies;
	private String location;
	private int pkg;
	private int criteria;
	private String stream;
	private String logo;
	public CompanyInsertPojo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CompanyInsertPojo(String companyName, String companyDescription, String designation, String email,
			int vacancies, String location, int pkg, int criteria, String stream, String logo) {
		super();
		this.companyName = companyName;
		this.companyDescription = companyDescription;
		this.designation = designation;
		this.email = email;
		this.vacancies = vacancies;
		this.location = location;
		this.pkg = pkg;
		this.criteria = criteria;
		this.stream = stream;
		this.logo = logo;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyDescription() {
		return companyDescription;
	}
	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getVacancies() {
		return vacancies;
	}
	public void setVacancies(int vacancies) {
		this.vacancies = vacancies;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getPkg() {
		return pkg;
	}
	public void setPkg(int pkg) {
		this.pkg = pkg;
	}
	public int getCriteria() {
		return criteria;
	}
	public void setCriteria(int criteria) {
		this.criteria = criteria;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}

	

}
