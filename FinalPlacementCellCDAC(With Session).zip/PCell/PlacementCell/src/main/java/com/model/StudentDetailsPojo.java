package com.model;

public class StudentDetailsPojo {
	
	private String fname;
	private String mname;
	private String lname;
	private String email;
	private String dob;
	private String gender;
	private String mobile;
	private String address;
	
	private String tenPer;
	private String tenYear;
	private String tenSchool;
	
	private String twlPer;
	private String twlYear;
	private String twlSchool;
	
	private String dipPer;
	private String dipYear;
	private String dipInstitute;
	private String dipStream;
	
	private String ugPer;
	private String ugYear;
	private String ugstream;
	private String ugInstitute;
	
	private String pgPer;
	private String pgYear;
	private String pgstream;
	private String pgInstitute;
	
	private String org;
	private String designation;
	private String duration;
	private String domain;
	
	private String language1;
	private String language2;
	private String language3;
	private String language4;
	
	public StudentDetailsPojo(String fname, String mname, String lname, String email, String dob, String gender,
			String mobile, String address, String tenPer, String tenYear, String tenSchool, String twlPer, String twlYear,
			String twlSchool, String dipPer, String dipYear, String dipInstitute, String dipStream, String ugPer, String ugYear,
			String ugstream, String ugInstitute, String pgPer, String pgYear, String pgstream, String pgInstitute, String org,
			String designation, String duration, String domain, String language1, String language2, String language3,
			String language4) {
		super();
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.email = email;
		this.dob = dob;
		this.gender = gender;
		this.mobile = mobile;
		this.address = address;
		this.tenPer = tenPer;
		this.tenYear = tenYear;
		this.tenSchool = tenSchool;
		this.twlPer = twlPer;
		this.twlYear = twlYear;
		this.twlSchool = twlSchool;
		this.dipPer = dipPer;
		this.dipYear = dipYear;
		this.dipInstitute = dipInstitute;
		this.dipStream = dipStream;
		this.ugPer = ugPer;
		this.ugYear = ugYear;
		this.ugstream = ugstream;
		this.ugInstitute = ugInstitute;
		this.pgPer = pgPer;
		this.pgYear = pgYear;
		this.pgstream = pgstream;
		this.pgInstitute = pgInstitute;
		this.org = org;
		this.designation = designation;
		this.duration = duration;
		this.domain = domain;
		this.language1 = language1;
		this.language2 = language2;
		this.language3 = language3;
		this.language4 = language4;
	}
	
	
	public String getDipStream() {
		return dipStream;
	}
	public void setDipStream(String dipStream) {
		this.dipStream = dipStream;
	}
	public String getLanguage1() {
		return language1;
	}
	public void setLanguage1(String language1) {
		this.language1 = language1;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTenPer() {
		return tenPer;
	}
	public void setTenPer(String tenPer) {
		this.tenPer = tenPer;
	}
	public String getTenYear() {
		return tenYear;
	}
	public void setTenYear(String tenYear) {
		this.tenYear = tenYear;
	}
	public String getTenSchool() {
		return tenSchool;
	}
	public void setTenSchool(String tenSchool) {
		this.tenSchool = tenSchool;
	}
	public String getTwlPer() {
		return twlPer;
	}
	public void setTwlPer(String twlPer) {
		this.twlPer = twlPer;
	}
	public String getTwlYear() {
		return twlYear;
	}
	public void setTwlYear(String twlYear) {
		this.twlYear = twlYear;
	}
	public String getTwlSchool() {
		return twlSchool;
	}
	public void setTwlSchool(String twlSchool) {
		this.twlSchool = twlSchool;
	}
	public String getDipPer() {
		return dipPer;
	}
	public void setDipPer(String dipPer) {
		this.dipPer = dipPer;
	}
	public String getDipYear() {
		return dipYear;
	}
	public void setDipYear(String dipYear) {
		this.dipYear = dipYear;
	}
	public String getDipInstitute() {
		return dipInstitute;
	}
	public void setDipInstitute(String dipInstitute) {
		this.dipInstitute = dipInstitute;
	}
	public String getUgPer() {
		return ugPer;
	}
	public void setUgPer(String ugPer) {
		this.ugPer = ugPer;
	}
	public String getUgYear() {
		return ugYear;
	}
	public void setUgYear(String ugYear) {
		this.ugYear = ugYear;
	}
	public String getUgstream() {
		return ugstream;
	}
	public void setUgstream(String ugstream) {
		this.ugstream = ugstream;
	}
	public String getUgInstitute() {
		return ugInstitute;
	}
	public void setUgInstitute(String ugInstitute) {
		this.ugInstitute = ugInstitute;
	}
	public String getPgPer() {
		return pgPer;
	}
	public void setPgPer(String pgPer) {
		this.pgPer = pgPer;
	}
	public String getPgYear() {
		return pgYear;
	}
	public void setPgYear(String pgYear) {
		this.pgYear = pgYear;
	}
	public String getPgstream() {
		return pgstream;
	}
	public void setPgstream(String pgstream) {
		this.pgstream = pgstream;
	}
	public String getPgInstitute() {
		return pgInstitute;
	}
	public void setPgInstitute(String pgInstitute) {
		this.pgInstitute = pgInstitute;
	}
	public String getOrg() {
		return org;
	}
	public void setOrg(String org) {
		this.org = org;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLanguage2() {
		return language2;
	}
	public void setLanguage2(String language2) {
		this.language2 = language2;
	}
	public String getLanguage3() {
		return language3;
	}
	public void setLanguage3(String language3) {
		this.language3 = language3;
	}
	public String getLanguage4() {
		return language4;
	}
	public void setLanguage4(String language4) {
		this.language4 = language4;
	}
//	photo rahila ahe
}