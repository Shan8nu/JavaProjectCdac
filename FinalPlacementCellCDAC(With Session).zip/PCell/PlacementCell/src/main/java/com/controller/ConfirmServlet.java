package com.controller;

import java.io.IOException;
import java.util.Properties;

import javax.mail.AuthenticationFailedException;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
public class ConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConfirmServlet()
    {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void processRequest(HttpServletRequest request,
            HttpServletResponse response) throws IOException, ServletException
	{
 
		HttpSession session1=request.getSession();
		String recepient=(String) session1.getAttribute("suser");
        
		final String err = "/Error.jsp";
        final String succ = "/success.jsp";
 
        
		String from = "udaydeorepatil@gmail.com";
        String to = recepient;						//"shantanup048@gmail.com";
        String subject = "Confirmation Mail For Job Interview via SOLUTION.COM";
        String message = "Dear "+recepient+" We are happy to that your resume "
        		+ "has been shortlisted for our company. For further selection process, you have been invited to attend the interview.";
        String login = "udaydeorepatil@gmail.com";
        String password = "Shan8nu@123gmail";
        
        System.out.println("In Send Mail");
        try {
            Properties props = new Properties();
            props.setProperty("mail.host", "smtp.gmail.com");
            props.setProperty("mail.smtp.port", "587");
            props.setProperty("mail.smtp.auth", "true");
            props.setProperty("mail.smtp.starttls.enable", "true");

            Authenticator auth = new SMTPAuthenticator(login, password);

            Session session = Session.getInstance(props, auth);
            
            // creates a new e-mail message
            Message msg = new MimeMessage(session);
     
            msg.setFrom(new InternetAddress(from));
            InternetAddress[] toAddresses = { new InternetAddress(to) };
            msg.setRecipients(Message.RecipientType.TO, toAddresses);
            msg.setSubject(subject);
           // msg.setSentDate(new Date());
            msg.setText(message);
       System.out.println("Before");
            // sends the e-mail
            Transport.send(msg);
  System.out.println("After");
        }catch (AuthenticationFailedException ex) {
        	System.out.println("In catch1");
            request.setAttribute("ErrorMessage", "Authentication failed");
 
            RequestDispatcher dispatcher = request.getRequestDispatcher(err);
            dispatcher.forward(request, response);
            return;
 
        } catch (AddressException ex) {
        	System.out.println("In catch2");
            request.setAttribute("ErrorMessage", "Wrong email address");
 
            RequestDispatcher dispatcher = request.getRequestDispatcher(err);
            dispatcher.forward(request, response);
            return;
        } catch (MessagingException ex) {
        	System.out.println("In catch3");
            request.setAttribute("ErrorMessage", ex.getMessage());
 
            RequestDispatcher dispatcher = request.getRequestDispatcher(err);
            dispatcher.forward(request, response);
            return;
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher(succ);
        dispatcher.forward(request, response);
        System.out.println("In ");
        return;
    }
 
    private class SMTPAuthenticator extends Authenticator {
 
        private PasswordAuthentication authentication;
 
        public SMTPAuthenticator(String login, String password) {
            authentication = new PasswordAuthentication(login, password);
        }
 
        protected PasswordAuthentication getPasswordAuthentication() {
            return authentication;
        }
    }
 
    
	
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("Send Mail");
		processRequest(request, response);
	}


}
