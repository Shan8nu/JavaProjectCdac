package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.*;

public class StudentLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public StudentLoginServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session=request.getSession();		
		String msg="Wrong Email or password";
		String lusername = request.getParameter("lusername");
		String lpassword = request.getParameter("lpassword");
		
		PojoClass pc = new PojoClass(lusername, lpassword);
		DaoLayer dl = new LoginDaoImlement(); 
		
		boolean log = dl.login(pc);
	if(log)
		{
		session.setAttribute("suser", lusername);
		session.setAttribute("spwd", lpassword);
		response.sendRedirect("CompanyCards.jsp");
		}
		else
		{
			session.setAttribute("error", msg);
			response.sendRedirect("StudentLogin.jsp");
		}	
	}
}