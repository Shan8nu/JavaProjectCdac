package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.model.DaoLayer;
import com.model.PojoClass;

public class StudentSignupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public StudentSignupServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String susername = request.getParameter("susername");
		String spassword = request.getParameter("spassword");
		String scpassword = request.getParameter("scpassword");
		
		PojoClass pc = new PojoClass(susername, spassword, scpassword);
		DaoLayer dl = new SignupDaoImplement(); 
		
		boolean insertRecord = dl.insertsignup(pc);
		
	if(insertRecord)
		{
		response.sendRedirect("Signup2.jsp");
		}
		else
		{
			out.println("<html><body><h1>record not inserted</h1></body></html>");
		}		
	}
}
