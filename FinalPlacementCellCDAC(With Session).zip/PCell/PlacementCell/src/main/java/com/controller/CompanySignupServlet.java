package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.CompanyInsertPojo;

public class CompanySignupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public CompanySignupServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();

		String cname = request.getParameter("cname");
		String cinfo = request.getParameter("cinfo");
		String designation = request.getParameter("designation");
		String cemail = request.getParameter("cemail");
		int vacancies = Integer.parseInt(request.getParameter("vacancies"));
		String location = request.getParameter("location");
		int pkg = Integer.parseInt(request.getParameter("package"));
		int criteria = Integer.parseInt(request.getParameter("criteria"));
		String stream = request.getParameter("stream");
		String logo = request.getParameter("logo");
		
		CompanyInsertPojo cpojo=new CompanyInsertPojo(cname, cinfo, designation, cemail, vacancies, location, pkg, criteria, stream, logo);
		CompanyInsertImpl dl=new CompanyInsertImpl();
		
		boolean insertRecord = dl.CompanyInsert(cpojo);
		
	if(insertRecord)
		{
			response.sendRedirect("CompanyDetails.jsp");
		}
		else
		{
			out.println("<html><body><h1>record not inserted</h1></body></html>");
		}		
	}

}
