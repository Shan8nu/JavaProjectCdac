package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class RemoveCompanyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public RemoveCompanyServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		int cid = Integer.parseInt(request.getParameter("cid"));

		RemoveCompanyImpl remove=new RemoveCompanyImpl();
		boolean log = remove.RemoveCompany(cid);
		
		if(log)
		{
			response.sendRedirect("CompanyDetails.jsp");
		}
		else
		{
			out.println("<html><body>alert('Wrong Email or password')</body></html>");
		}	
	}

}
