package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.DaoLayer;
import com.model.PojoClass;
import com.model.StudentDetailsPojo;

public class StudentDetailServlet extends HttpServlet {
	 private static final long serialVersionUID = 1L;
 
    public StudentDetailServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String fname = request.getParameter("fname");
		String mname = request.getParameter("mname");
		String lname = request.getParameter("lname");
		String email = request.getParameter("email");
		String dob = request.getParameter("dob");
		String gender = request.getParameter("gender");
		String mobile = request.getParameter("mobile");
		String address = request.getParameter("address");
		
		int tenPer = Integer.parseInt(request.getParameter("tenPer"));
		int tenYear = Integer.parseInt(request.getParameter("tenYear"));
		String tenSchool = request.getParameter("tenSchool"); 
		
		int twlPer = Integer.parseInt(request.getParameter("twlPer"));
		int twlYear = Integer.parseInt(request.getParameter("twlYear"));
		String twlSchool = request.getParameter("twlSchool");
		
		int dipPer = Integer.parseInt(request.getParameter("dipPer"));
		int dipYear = Integer.parseInt(request.getParameter("dipYear"));
		String dipInstitute = request.getParameter("dipInstitute");
		String dipStream = request.getParameter("dipStream");
		
		int ugPer = Integer.parseInt(request.getParameter("ugPer"));
		int ugYear = Integer.parseInt(request.getParameter("ugYear"));
		String ugstream = request.getParameter("ugstream");
		String ugInstitute = request.getParameter("ugInstitute");
		
		int pgPer = Integer.parseInt(request.getParameter("pgPer"));
		int pgYear= Integer.parseInt(request.getParameter("pgYear"));
		String pgstream = request.getParameter("pgstream");
		String pgInstitute = request.getParameter("pgInstitute");
		
		String org = request.getParameter("org"); 
		String designation = request.getParameter("designation");
		String duration = request.getParameter("duration");
		String domain = request.getParameter("domain");
		
		String language1 = request.getParameter("language1");
		String language2 = request.getParameter("language2");
		String language3 = request.getParameter("language3");
		String language4 = request.getParameter("language4");
		

		StudentDetailsPojo sdp = new StudentDetailsPojo(fname, mname, lname, email, dob, gender, mobile, address, tenPer, tenYear, tenSchool, twlPer, twlYear, twlSchool, dipPer, dipYear, dipInstitute, dipStream, ugPer, ugYear, ugstream, ugInstitute, pgPer, pgYear, pgstream, pgInstitute, org, designation, duration, domain, language1, language2, language3, language4);
		DaoLayer dl = new StudentDetailImplement(); 
		
		boolean insertRecord = dl.studentDataInsert(sdp);
		
	if(insertRecord)
		{
			out.println("<html><body><h1>"+fname+"</h1></body></html>");
			dl.studentDataInsert(sdp);
		}
		else
		{
			out.println("<html><body><h1>record not inserted</h1></body></html>");
		}
		
	}

}
