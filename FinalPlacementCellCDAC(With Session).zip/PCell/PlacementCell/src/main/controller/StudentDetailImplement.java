package com.controller;

import java.sql.Connection;

import com.model.DaoLayer;
import com.model.DbConnection;
import com.model.PojoClass;
import com.model.StudentDetailsPojo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentDetailImplement implements DaoLayer{

	Connection con = null;
	@Override
	public boolean studentDataInsert(StudentDetailsPojo sdp) {
				
		try {
			con = DbConnection.getConnection();
			ResultSet rs=null;
			PreparedStatement pst=null;
			PreparedStatement pst1=null;
			PreparedStatement pst3=null;

			
			String query1 = "insert into personaldetails values(default,?,?,?,?,?,?,?,?)";			
			
			pst = con.prepareStatement(query1);
			
			pst.setString(1, sdp.getFname());
			pst.setString(2, sdp.getMname());
			pst.setString(3, sdp.getLname());
			pst.setString(4, sdp.getAddress());
			pst.setString(5, sdp.getMobile());
			pst.setString(6, sdp.getEmail());
			pst.setString(7, sdp.getDob());
			pst.setString(8, sdp.getGender());
			
			int personal = pst.executeUpdate();	//student details execute
			
			if(true)
			{	
				System.out.println("personal record inserted");
				
				Connection con2 = DbConnection.getConnection();
				
				String query2 = "select last_insert_id() from placement.personaldetails";
				System.out.println("after query");
				
				pst1 = con2.prepareStatement(query2);
				System.out.println("after prepare");
			
				rs = pst1.executeQuery();	//last id execute
				System.out.println("after executeQuery");				
				
				if(true)
				{
					System.out.println("in if true	");
					
					String query3 = "insert into educationdetails values(default,x,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
					pst3 = con.prepareStatement(query3);
					System.out.println("in if 	");
					
					pst.setInt(1, sdp.getTenPer());
					pst.setInt(2, sdp.getTenYear());
					pst.setString(3, sdp.getTenSchool());
					pst.setInt(4, sdp.getTwlPer());
					pst.setInt(5, sdp.getTwlYear());
					pst.setString(6, sdp.getTwlSchool());
					pst.setInt(7, sdp.getDipPer());
					pst.setInt(8, sdp.getDipYear());
					pst.setString(9, sdp.getDipInstitute());
					pst.setString(10, sdp.getDipStream());
					pst.setInt(11, sdp.getUgPer());
					pst.setInt(12, sdp.getUgYear());
					pst.setString(13, sdp.getUgInstitute());
					pst.setString(14, sdp.getUgstream());
					pst.setInt(15, sdp.getPgPer());
					pst.setInt(16, sdp.getPgYear());
					pst.setString(17, sdp.getPgInstitute());
					pst.setString(18, sdp.getPgstream());
				
					int education = pst3.executeUpdate();
					System.out.println("in if triuhbjhbe	");

					
					if(true)
					{
						System.out.println("education");
						return true;
					}
					
				}
				
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
			return false;
	}
	
	@Override
	public boolean insertsignup(PojoClass pc) {
		return false;
	}

	@Override
	public boolean login(PojoClass pc) {
		return false;
	}
}
