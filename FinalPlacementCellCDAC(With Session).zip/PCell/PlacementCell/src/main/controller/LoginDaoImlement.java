package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.DaoLayer;
import com.model.DbConnection;
import com.model.PojoClass;
import com.model.StudentDetailsPojo;

public class LoginDaoImlement implements DaoLayer{
	@Override
	public boolean login(PojoClass pc) 
	{
		Connection con = null;
		try {
			con  = DbConnection.getConnection();
			String query="select * from signup where uname=?  && password=?";
						
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, pc.getLusername());
			pst.setString(2, pc.getLpassword());

			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
			{
				System.out.println("true");
				return true;
			}
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				con.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		return false;
	}

	@Override
	public boolean insertsignup(PojoClass pc) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean studentDataInsert(StudentDetailsPojo sdp) {
		// TODO Auto-generated method stub
		return false;
	}	

}
