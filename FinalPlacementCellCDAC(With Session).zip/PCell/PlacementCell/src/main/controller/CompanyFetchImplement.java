package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.model.DbConnection;

public class CompanyFetchImplement {

	Connection con = null;

	public ResultSet CompanyInfoFetch()
	{
    	String query = "select * from companylist";
    	try 
    	{
    		con = DbConnection.getConnection();
			PreparedStatement pst = con.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			return rs;
    	}
    	catch (Exception e) 
    	{
			e.printStackTrace();
		}
		return null;
		
	}
}
