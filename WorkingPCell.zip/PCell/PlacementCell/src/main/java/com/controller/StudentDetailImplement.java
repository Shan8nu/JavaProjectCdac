package com.controller;

import java.sql.Connection;

import com.model.DaoLayer;
import com.model.DbConnection;
import com.model.PojoClass;
import com.model.StudentDetailsPojo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentDetailImplement implements DaoLayer{

	long studentid;
	Connection con = null;
	@Override
	public boolean studentDataInsert(StudentDetailsPojo sdp) {
				
		try {
			con = DbConnection.getConnection();
			ResultSet rs=null;
			PreparedStatement pst=null;
			PreparedStatement pst1=null;
			PreparedStatement pst3=null;
			PreparedStatement pst4=null;
			PreparedStatement pst5=null;

			String query1 = "insert into personaldetails values(default,?,?,?,?,?,?,?,?)";			
			
			pst = con.prepareStatement(query1);
			
			pst.setString(1, sdp.getFname());
			pst.setString(2, sdp.getMname());
			pst.setString(3, sdp.getLname());
			pst.setString(4, sdp.getAddress());
			pst.setString(5, sdp.getMobile());
			pst.setString(6, sdp.getEmail());
			pst.setString(7, sdp.getDob());
			pst.setString(8, sdp.getGender());
			
			int personal = pst.executeUpdate();	
			
			String query2 = "select last_insert_id()";
			
			pst1 = con.prepareStatement(query2);
		
			rs = pst1.executeQuery();
			System.out.println("last id");

			if(rs.next())
				{
					studentid = rs.getLong(1);
				}
			
			
			if(personal>0)
			{	
					System.out.println("personal inserted");
					System.out.println("education part");

					con = DbConnection.getConnection();

					String query3 = "insert into educationdetails values(default,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
					pst3 = con.prepareStatement(query3);
					
//					String a = Integer.toString(sdp.getTenPer());
//this is integer to string conversion prototype					
//					if((Integer.toString(sdp.getTenPer())==""))
//							pst3.setString(2,0);
//					else
					
					pst3.setLong(1, studentid);
					pst3.setString(2,sdp.getTenPer());	
					pst3.setString(3, sdp.getTenYear());
					pst3.setString(4, sdp.getTenSchool());					

					if(sdp.getTwlPer()=="")
					{	
						pst3.setString(5, null);
						pst3.setString(6, null);
						pst3.setString(7, null);
					}
					else
					{
						pst3.setString(5, sdp.getTwlPer());
						pst3.setString(6, sdp.getTwlYear());
						pst3.setString(7, sdp.getTwlSchool());	
					}
						
					if(sdp.getDipYear()=="")
					{
						pst3.setString(8, null);
						pst3.setString(9, null);
						pst3.setString(10, null);
						pst3.setString(11, null);
					}
					else
					{
						pst3.setString(8, sdp.getDipPer());
						pst3.setString(9, sdp.getDipYear());
						pst3.setString(10, sdp.getDipInstitute());
						pst3.setString(11, sdp.getDipStream());
					}
					
					pst3.setString(12, sdp.getUgPer());
					pst3.setString(13, sdp.getUgYear());
					pst3.setString(14, sdp.getUgInstitute());
					pst3.setString(15, sdp.getUgstream());
					
					if(sdp.getPgPer()=="")
					{
						pst3.setString(16, null);
						pst3.setString(17, null);
						pst3.setString(18, null);
						pst3.setString(19, null);
					}
					else
					{
						pst3.setString(16, sdp.getPgPer());
						pst3.setString(17, sdp.getPgYear());
						pst3.setString(18, sdp.getPgInstitute());
						pst3.setString(19, sdp.getPgstream());
					}
				
					int education = pst3.executeUpdate();
					
					if(education>0)
					{
						System.out.println("education inserted");
						System.out.println("experience part");
						
//						insert into experience values(default,4,"sd","sf",20,"nk");
						String query4 = "insert into experience values(default,?,?,?,?,?)";			
						
						pst4 = con.prepareStatement(query4);
						
						pst4.setLong(1, studentid);
						
						if(sdp.getOrg()=="" || sdp.getDesignation()=="" || sdp.getDuration()=="" || sdp.getDomain()=="")
						{
							pst4.setString(2, null);
							pst4.setString(3, null);
							pst4.setString(4, null);
							pst4.setString(5, null);
						}
						else
						{
							pst4.setString(2, sdp.getOrg());
							pst4.setString(3, sdp.getDesignation());
							pst4.setString(4, sdp.getDuration());
							pst4.setString(5, sdp.getDomain());
						}
						
						
						int experience = pst4.executeUpdate();
						
						if(experience>0)
						{
							System.out.println("experience inserted");
							System.out.println("language part");
							
							String query5 = "insert into languages values(default,?,?,?,?,?)";			
							
							pst5 = con.prepareStatement(query5);
							
							pst5.setLong(1, studentid);
							
							if(sdp.getLanguage1()=="")
							{
								pst5.setString(2, null);
							}
							else
								pst5.setString(2, sdp.getLanguage1());
							
							if(sdp.getLanguage2()=="")
							{
								pst5.setString(3, null);
							}
							else
								pst5.setString(3, sdp.getLanguage2());
							
							if(sdp.getLanguage3()=="")
							{
								pst5.setString(4, null);
							}
							else
								pst5.setString(4, sdp.getLanguage3());
							
							if(sdp.getLanguage4()=="")
							{
								pst5.setString(5, null);
							}
							else
								pst5.setString(5, sdp.getLanguage4());
							
							int language = pst5.executeUpdate();	//student details execute
							System.out.println("language inserted");
							
							return true;
						}						
				}				
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
				System.out.println("in close");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
			return false;
	}
	
	@Override
	public boolean insertsignup(PojoClass pc) {
		return false;
	}

	@Override
	public boolean login(PojoClass pc) {
		return false;
	}
}
