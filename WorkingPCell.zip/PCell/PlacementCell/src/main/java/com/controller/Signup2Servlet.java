package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Signup2Pojo;

public class Signup2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public Signup2Servlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String country = request.getParameter("country");
		String state = request.getParameter("state");
		String city = request.getParameter("city");
		
		Signup2Pojo s2p = new Signup2Pojo(country, state, city);
		
		Signup2Implement s2i = new Signup2Implement();
		
		boolean insertrecord = s2i.insertSignup2(s2p);
		
		if(insertrecord)
		{
			response.sendRedirect("StudentLogin.jsp");
		}
		
	}
}
