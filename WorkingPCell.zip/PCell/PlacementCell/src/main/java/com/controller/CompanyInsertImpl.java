package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.model.CompanyInsertPojo;
import com.model.DbConnection;

public class CompanyInsertImpl 
{
	Connection con = null;
	public boolean CompanyInsert(CompanyInsertPojo cinsert)
	{	
		String query = "insert into companylist values(default,?,?,?,?,?,?,?,?,?,?)";
		try {
			con  = DbConnection.getConnection();
			PreparedStatement pst = con.prepareStatement(query);

			pst.setString(1, cinsert.getCompanyName());
			pst.setString(2, cinsert.getCompanyDescription());
			pst.setString(3, cinsert.getDesignation());
			pst.setString(4, cinsert.getEmail());
			pst.setInt(5, cinsert.getVacancies());
			pst.setString(6, cinsert.getLocation());
			pst.setInt(7, cinsert.getPkg());
			pst.setInt(8, cinsert.getCriteria());
			pst.setString(9, cinsert.getStream());
			pst.setString(10, cinsert.getLogo());

			
			int record = pst.executeUpdate();
			
			if(record==1)
				{
					System.out.println("Insert successfully");
					return true;				
				}		
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}	
	return false;
	}
}
