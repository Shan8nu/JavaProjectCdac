package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.DaoLayer;
import com.model.PojoClass;

public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public AdminLoginServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();              
		String lusername = request.getParameter("username");
		String lpassword = request.getParameter("password");
		
		PojoClass pc = new PojoClass(lusername, lpassword);
		DaoLayer dl = new LoginDaoImlement(); 
		
		boolean log = dl.login(pc);
	if(log)
		{
		HttpSession Adminsession=request.getSession();
		Adminsession.setAttribute("suser", lusername);	
		response.sendRedirect("AdminDetails.jsp");
		}
		else
		{
			out.println("<html><body>alert('Wrong Email or password')</body></html>");
		}	

	}

}
