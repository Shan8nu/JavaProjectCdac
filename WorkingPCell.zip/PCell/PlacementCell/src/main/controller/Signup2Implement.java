package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.model.DbConnection;
import com.model.Signup2Pojo;

public class Signup2Implement {
	
	Connection con = null;

	 public boolean insertSignup2(Signup2Pojo s2p)
	    {	    	
	    	String query = "insert into signup2 values(default,?,?,?)";
	    	try {
	    		con = DbConnection.getConnection();
				PreparedStatement pst = con.prepareStatement(query);
				
				pst.setString(1,s2p.getCountry());
				pst.setString(2,s2p.getState());
				pst.setString(3,s2p.getCity());
				
				int record = pst.executeUpdate();
				
				if(record==1)
				{
					System.out.println("signup2");
					return true;
				}

			} 
	    	catch (ClassNotFoundException e) 
			{
				e.printStackTrace();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}	    	
	    	return false;
	    }

}
