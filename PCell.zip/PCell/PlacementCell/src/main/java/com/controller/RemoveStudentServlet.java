package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RemoveStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
        public RemoveStudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		int srno = Integer.parseInt(request.getParameter("id"));

		RemoveStudentImpl remove=new RemoveStudentImpl();
		boolean log = remove.RemoveStudent(srno);
		
		if(log)
		{
			response.sendRedirect("AdminDetails.jsp");
		}
		else
		{
			out.println("<html><body>alert('Wrong Email or password')</body></html>");
		}	

	}

}
