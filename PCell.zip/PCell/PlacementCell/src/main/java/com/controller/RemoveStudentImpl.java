package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.model.DbConnection;

public class RemoveStudentImpl 
{
	Connection con = null;
	public boolean RemoveStudent(int sid)
	{
		String query1 = "delete from educationdetails where studentid=?";		
		try {
    		con = DbConnection.getConnection();
			PreparedStatement pst = con.prepareStatement(query1);
			pst.setInt(1, sid);
			int record = pst.executeUpdate();	
			if(record==1)
			{
		    	String query = "delete from personaldetails where id=?";
		    	try {
					PreparedStatement pst1 = con.prepareStatement(query);
					pst1.setInt(1, sid);
					int record1 = pst.executeUpdate();
					
					if(record==1)
					{
						System.out.println("deleted");
						return true;
					}
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}	    	
		    	return false;
			}
		} 
    	catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}	    	
		return false;
	}

}
