package com.model;

public class StudentDetailsPojo {
	
	private int id;
	private String fname;
	private String mname;
	private String lname;
	private String email;
	private String dob;
	private String gender;
	private String mobile;
	private String address;
	
	public StudentDetailsPojo(String fname, String mname, String lname, String email, String dob, String gender,
			String mobile, String address, int tenPer, int tenYear, String tenSchool, int twlPer, int twlYear,
			String twlSchool, int dipPer, int dipYear, String dipInstitute, String dipStream, int ugPer, int ugYear,
			String ugstream, String ugInstitute, int pgPer, int pgYear, String pgstream, String pgInstitute, String org,
			String designation, String duration, String domain, String language1, String language2, String language3,
			String language4) {
		super();

		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.email = email;
		this.dob = dob;
		this.gender = gender;
		this.mobile = mobile;
		this.address = address;
		this.tenPer = tenPer;
		this.tenYear = tenYear;
		this.tenSchool = tenSchool;
		this.twlPer = twlPer;
		this.twlYear = twlYear;
		this.twlSchool = twlSchool;
		this.dipPer = dipPer;
		this.dipYear = dipYear;
		this.dipInstitute = dipInstitute;
		this.dipStream = dipStream;
		this.ugPer = ugPer;
		this.ugYear = ugYear;
		this.ugstream = ugstream;
		this.ugInstitute = ugInstitute;
		this.pgPer = pgPer;
		this.pgYear = pgYear;
		this.pgstream = pgstream;
		this.pgInstitute = pgInstitute;
		this.org = org;
		this.designation = designation;
		this.duration = duration;
		this.domain = domain;
		this.language1 = language1;
		this.language2 = language2;
		this.language3 = language3;
		this.language4 = language4;
	}
	private int tenPer;
	private int tenYear;
	private String tenSchool;
	
	private int twlPer;
	private int twlYear;
	private String twlSchool;
	
	private int dipPer;
	private int dipYear;
	private String dipInstitute;
	private String dipStream;
	
	private int ugPer;
	private int ugYear;
	private String ugstream;
	private String ugInstitute;
	
	private int pgPer;
	private int pgYear;
	private String pgstream;
	private String pgInstitute;
	
	private String org;
	private String designation;
	private String duration;
	private String domain;
	
	private String language1;
	private String language2;
	private String language3;
	private String language4;
	
	public String getDipStream() {
		return dipStream;
	}
	public void setDipStream(String dipStream) {
		this.dipStream = dipStream;
	}
	public String getLanguage1() {
		return language1;
	}
	public void setLanguage1(String language1) {
		this.language1 = language1;
	}
	public String getFname() {
		return fname;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getTenPer() {
		return tenPer;
	}
	public void setTenPer(int tenPer) {
		this.tenPer = tenPer;
	}
	public int getTenYear() {
		return tenYear;
	}
	public void setTenYear(int tenYear) {
		this.tenYear = tenYear;
	}
	public String getTenSchool() {
		return tenSchool;
	}
	public void setTenSchool(String tenSchool) {
		this.tenSchool = tenSchool;
	}
	public int getTwlPer() {
		return twlPer;
	}
	public void setTwlPer(int twlPer) {
		this.twlPer = twlPer;
	}
	public int getTwlYear() {
		return twlYear;
	}
	public void setTwlYear(int twlYear) {
		this.twlYear = twlYear;
	}
	public String getTwlSchool() {
		return twlSchool;
	}
	public void setTwlSchool(String twlSchool) {
		this.twlSchool = twlSchool;
	}
	public int getDipPer() {
		return dipPer;
	}
	public void setDipPer(int dipPer) {
		this.dipPer = dipPer;
	}
	public int getDipYear() {
		return dipYear;
	}
	public void setDipYear(int dipYear) {
		this.dipYear = dipYear;
	}
	public String getDipInstitute() {
		return dipInstitute;
	}
	public void setDipInstitute(String dipInstitute) {
		this.dipInstitute = dipInstitute;
	}
	public int getUgPer() {
		return ugPer;
	}
	public void setUgPer(int ugPer) {
		this.ugPer = ugPer;
	}
	public int getUgYear() {
		return ugYear;
	}
	public void setUgYear(int ugYear) {
		this.ugYear = ugYear;
	}
	public String getUgstream() {
		return ugstream;
	}
	public void setUgstream(String ugstream) {
		this.ugstream = ugstream;
	}
	public String getUgInstitute() {
		return ugInstitute;
	}
	public void setUgInstitute(String ugInstitute) {
		this.ugInstitute = ugInstitute;
	}
	public int getPgPer() {
		return pgPer;
	}
	public void setPgPer(int pgPer) {
		this.pgPer = pgPer;
	}
	public int getPgYear() {
		return pgYear;
	}
	public void setPgYear(int pgYear) {
		this.pgYear = pgYear;
	}
	public String getPgstream() {
		return pgstream;
	}
	public void setPgstream(String pgstream) {
		this.pgstream = pgstream;
	}
	public String getPgInstitute() {
		return pgInstitute;
	}
	public void setPgInstitute(String pgInstitute) {
		this.pgInstitute = pgInstitute;
	}
	public String getOrg() {
		return org;
	}
	public void setOrg(String org) {
		this.org = org;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLanguage2() {
		return language2;
	}
	public void setLanguage2(String language2) {
		this.language2 = language2;
	}
	public String getLanguage3() {
		return language3;
	}
	public void setLanguage3(String language3) {
		this.language3 = language3;
	}
	public String getLanguage4() {
		return language4;
	}
	public void setLanguage4(String language4) {
		this.language4 = language4;
	}
//	photo rahila ahe
}