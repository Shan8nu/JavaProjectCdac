package com.model;

public class PojoClass {

	private String susername;
	private String spassword;
	private String scpassword;
	private String lusername;
	private String lpassword;
	
	public PojoClass(String lusername, String lpassword) {
		super();
		this.lusername = lusername;
		this.lpassword = lpassword;
	}
	public PojoClass(String susername, String spassword, String scpassword) {
		super();
		this.susername = susername;
		this.spassword = spassword;
		this.scpassword = scpassword;
	}
	public String getLusername() {
		return lusername;
	}
	public void setLusername(String lusername) {
		this.lusername = lusername;
	}
	public String getLpassword() {
		return lpassword;
	}
	public void setLpassword(String lpassword) {
		this.lpassword = lpassword;
	}
	public String getsusername() {
		return susername;
	}
	public void setsusername(String susername) {
		this.susername = susername;
	}
	public String getspassword() {
		return spassword;
	}
	public void setspassword(String spassword) {
		this.spassword = spassword;
	}
	public String getscpassword() {
		return scpassword;
	}
	public void setscpassword(String scpassword) {
		this.scpassword = scpassword;
	}
	@Override
	public String toString() {
		return "PojoClass [susername=" + susername + ", spassword=" + spassword + ", scpassword=" + scpassword + "]";
	}
	
}
