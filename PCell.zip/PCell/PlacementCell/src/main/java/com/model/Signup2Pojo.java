package com.model;

public class Signup2Pojo {

	private String Country;
	private String City;
	private String State;
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public Signup2Pojo(String country, String city, String state) {
		super();
		Country = country;
		City = city;
		State = state;
	}
	
	
}
